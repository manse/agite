chrome.devtools.panels.create(
  'Agite',
  'frontend/img/icon.png',
  'frontend/panel.html'
);
